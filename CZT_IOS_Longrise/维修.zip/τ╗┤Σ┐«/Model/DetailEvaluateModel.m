//
//  DetailEvaluateModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "DetailEvaluateModel.h"

@implementation DetailEvaluateModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end
