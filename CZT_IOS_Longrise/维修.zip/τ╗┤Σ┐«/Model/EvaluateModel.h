//
//  EvaluateModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/22.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"

@interface EvaluateModel : JSONModel

@property (nonatomic, copy) NSString *evaluatedetails;
@property (nonatomic, copy) NSString *evaluateservice;
@property (nonatomic, copy) NSString *evaluateefficiency;
@property (nonatomic, copy) NSString *evaluateenvironment;
@property (nonatomic, copy) NSString *evaluatetotledetails;
@property (nonatomic, copy) NSString *evaluatequality;
@property (nonatomic, copy) NSString *evaluateprice;

@end
