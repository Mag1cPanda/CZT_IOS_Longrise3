//
//  HRDetailModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/22.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "HRDetailModel.h"

@implementation HRDetailModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end
