//
//  DetailDataModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/22.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"
#import "DetailInfoModel.h"
#import "DetailEvaluateModel.h"

@interface DetailDataModel : JSONModel

@property (nonatomic, strong) DetailInfoModel *companyinfo;
@property (nonatomic, strong) DetailEvaluateModel *companyevaluate;

@end
