//
//  WXModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "WXModel.h"

@implementation WXModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}

@end
