//
//  SeviceItemsModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/22.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "SeviceItemsModel.h"

@implementation SeviceItemsModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end
