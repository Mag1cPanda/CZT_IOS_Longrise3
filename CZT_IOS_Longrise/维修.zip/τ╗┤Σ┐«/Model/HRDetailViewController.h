//
//  HRDetailViewController.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/12.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRDataModel.h"
@interface HRDetailViewController : UIViewController
//头部视图数据
@property (nonatomic, strong) HRDataModel *model;


@property (nonatomic, copy) NSString *Id;//请求数据用的id
@end
