//
//  HealthRecordModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/21.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"
#import "HRDataModel.h"
@interface HealthRecordModel : JSONModel

@property (nonatomic, strong) NSArray<HRDataModel> *data;

@end
