//
//  SeviceItemsModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/22.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"
#import "EvaluateModel.h"
@protocol SeviceItemsModel <NSObject>


@end

@interface SeviceItemsModel : JSONModel

@property (nonatomic, strong) EvaluateModel *belcipcarownerevaluate;

@end
