//
//  WXModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

//此为车辆管理模型
#import "JSONModel.h"
#import "CarModel.h"
@interface WXModel : JSONModel
@property (nonatomic, strong) NSArray<CarModel> *data;
@end
