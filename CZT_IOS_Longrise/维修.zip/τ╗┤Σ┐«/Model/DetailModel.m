//
//  DetailModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "DetailModel.h"

@implementation DetailModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end
