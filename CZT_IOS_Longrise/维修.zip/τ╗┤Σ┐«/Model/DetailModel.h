//
//  DetailModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"
#import "DetailDataModel.h"
@interface DetailModel : JSONModel
@property (nonatomic, strong) NSString *restate;
@property (nonatomic, strong) NSString *redes;
@property (nonatomic, strong) DetailDataModel *data;

@end
