//
//  HealthRecordModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/21.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "HealthRecordModel.h"

@implementation HealthRecordModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end
