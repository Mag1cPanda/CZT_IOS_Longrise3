//
//  ResultModel.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/14.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "ResultModel.h"

@implementation ResultModel
+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}


@end
