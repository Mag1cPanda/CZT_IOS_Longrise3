//
//  DetailInfoModel.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/17.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "JSONModel.h"

@interface DetailInfoModel : JSONModel

@property (nonatomic, copy) NSString *companycode;
@property (nonatomic, copy) NSString *businessrange;
@property (nonatomic, copy) NSString *orgnumber;
@property (nonatomic, copy) NSString *evaluateprice;
@property (nonatomic, copy) NSString *linkmobile;
@property (nonatomic, copy) NSString *companyphoto;
@property (nonatomic, copy) NSString *evaluatequality;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *areaid;
@property (nonatomic, copy) NSString *redes;
@property (nonatomic, copy) NSString *Id;
@property (nonatomic, strong) NSNumber *restate;
@property (nonatomic, copy) NSString *linkman;
@property (nonatomic, copy) NSString *badnum;
@property (nonatomic, copy) NSString *ratenum;
@property (nonatomic, copy) NSString *linktel;
@property (nonatomic, copy) NSString *middlenum;
@property (nonatomic, copy) NSString *peoplenumber;
@property (nonatomic, copy) NSString *evaluateservice;
@property (nonatomic, copy) NSString *levels;
@property (nonatomic, copy) NSString *evaluateefficiency;
@property (nonatomic, copy) NSString *rate;
@property (nonatomic, copy) NSString *evaluateenvironment;
@property (nonatomic, copy) NSString *address;
@property (nonatomic, copy) NSString *industryid;

@end
