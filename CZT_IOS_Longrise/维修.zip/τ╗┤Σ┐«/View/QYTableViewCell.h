//
//  QYTableViewCell.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/9.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CWStarRateView.h"
#import "ResultModel.h"
@interface QYTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *icon;

@property (weak, nonatomic) IBOutlet UILabel *nameLab;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *rateCount;
@property (weak, nonatomic) IBOutlet UILabel *goodRate;


-(void)setUIWithInfo:(ResultModel *)model;

@end
