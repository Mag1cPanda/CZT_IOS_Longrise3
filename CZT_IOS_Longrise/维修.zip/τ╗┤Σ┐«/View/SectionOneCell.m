//
//  SectionOneCell.m
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/11.
//  Copyright © 2015年 程三. All rights reserved.
//

#import "SectionOneCell.h"

@implementation SectionOneCell
-(void)setUIWithInfo:(DetailInfoModel *)model{

    self.mainLab.text = model.businessrange;

}

- (void)awakeFromNib {
    // Initialization code
//    [AppDelegate storyBoradAutoLay:self];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
