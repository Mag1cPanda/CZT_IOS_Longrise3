//
//  HRDetailSectionOneCell.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/12.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRDetailDataModel.h"
@interface HRDetailSectionOneCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *materialFee;
@property (weak, nonatomic) IBOutlet UILabel *workingHoursFee;
@property (weak, nonatomic) IBOutlet UILabel *othersFee;
@property (weak, nonatomic) IBOutlet UILabel *totalLab;

-(void)setUIWithInfo:(HRDetailDataModel *)model;
@end
