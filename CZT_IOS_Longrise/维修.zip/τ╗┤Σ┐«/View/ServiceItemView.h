//
//  ServiceItemView.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 16/1/15.
//  Copyright © 2016年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceItemView : UIView
@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) UILabel *itemLab;
@end
