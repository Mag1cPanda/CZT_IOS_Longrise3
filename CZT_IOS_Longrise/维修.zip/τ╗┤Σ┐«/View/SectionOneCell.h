//
//  SectionOneCell.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/11.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailInfoModel.h"
@interface SectionOneCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *mainLab;
-(void)setUIWithInfo:(DetailInfoModel *)model;

@end
