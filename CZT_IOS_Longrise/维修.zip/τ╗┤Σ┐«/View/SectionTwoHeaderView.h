//
//  SectionTwoHeaderView.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/23.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailInfoModel.h"
@interface SectionTwoHeaderView : UIView

@property (weak, nonatomic) IBOutlet UILabel *total;
@property (weak, nonatomic) IBOutlet UILabel *good;
@property (weak, nonatomic) IBOutlet UILabel *middle;
@property (weak, nonatomic) IBOutlet UILabel *bad;

-(void)setUIWithInfo:(DetailInfoModel *)model;

@end
