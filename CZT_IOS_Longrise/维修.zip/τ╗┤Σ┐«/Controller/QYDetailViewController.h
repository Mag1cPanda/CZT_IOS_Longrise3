//
//  QYDetailViewController.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/10.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface QYDetailViewController : BaseViewController

@property (nonatomic, strong) NSString *companyId;
@property (nonatomic, strong) NSString *areaId;

@end
