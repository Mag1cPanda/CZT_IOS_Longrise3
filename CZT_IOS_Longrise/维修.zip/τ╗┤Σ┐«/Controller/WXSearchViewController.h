//
//  WXSearchViewController.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/18.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXSearchViewController : UIViewController
@property (nonatomic, strong) NSMutableArray *wxDataArray;
@property (nonatomic, strong) NSString *searchString;
@end
