//
//  HealthRecordViewController.h
//  CZT_IOS_Longrise
//
//  Created by Siren on 15/12/12.
//  Copyright © 2015年 程三. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface HealthRecordViewController : UIViewController
@property (nonatomic,copy)NSString *carNo;
@end
